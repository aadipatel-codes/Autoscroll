let refreshIntervalId;
let autoRefreshEnabled = false;

chrome.runtime.onInstalled.addListener(() => {
  console.log("Auto Scroll Extension installed.");
});

// Function to start or stop auto refresh
function toggleAutoRefresh(enabled) {
  autoRefreshEnabled = enabled;
  if (autoRefreshEnabled) {
    startAutoRefresh();
  } else {
    stopAutoRefresh();
  }
}

// Function to start auto refresh
function startAutoRefresh() {
  const intervalTime = 1000; // 30 minutes in milliseconds
  refreshIntervalId = setInterval(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.reload(tabs[0].id);
    });
  }, intervalTime);
}

// Function to stop auto refresh
function stopAutoRefresh() {
  clearInterval(refreshIntervalId);
}

// Message listener from popup.js or other parts of the extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'setAutoScroll') {
    toggleAutoScroll(message.enabled);
    sendResponse({ status: 'Auto scroll set' });
  } else if (message.type === 'setAutoRefresh') {
    toggleAutoRefresh(message.enabled);
    sendResponse({ status: 'Auto refresh set' });
  }
});
