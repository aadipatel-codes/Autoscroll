let intervalId;

chrome.storage.local.get('autoScroll', (data) => {
  if (data.autoScroll) {
    startScrolling();
  }
});

function startScrolling() {
  intervalId = setInterval(() => {
    window.scrollBy(0, 1);

    if ((window.innerHeight + window.scrollY) >= document.body.scrollHeight) {
      window.scrollTo(0, 0);
    }
  }, 60); // Adjust the speed as needed
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.autoScroll) {
    if (changes.autoScroll.newValue) {
      startScrolling();
    } else {
      clearInterval(intervalId);
    }
  }
});