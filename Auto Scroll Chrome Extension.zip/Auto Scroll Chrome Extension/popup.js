document.getElementById('start').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ['content.js']
      });
      chrome.storage.local.set({ autoScroll: true });
    });
  });
  
  document.getElementById('stop').addEventListener('click', () => {
    chrome.storage.local.set({ autoScroll: false });
  });
  
  document.getElementById('startRefresh').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'setAutoRefresh', enabled: true });
  });
  
  document.getElementById('stopRefresh').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'setAutoRefresh', enabled: false });
  });
  